package com.example.seeddetail;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;

public class SeedDisplayMod implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        HudRenderCallback.EVENT.register((matrices, tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client != null && client.world != null && client.player != null && client.options.debugEnabled) {
                long seed = client.world.getSeed();
                String seedText = "Seed: " + seed;
                client.textRenderer.drawWithShadow(matrices, seedText, 10, 10, 0xFFFFFF);
            }
        });
    }
}
